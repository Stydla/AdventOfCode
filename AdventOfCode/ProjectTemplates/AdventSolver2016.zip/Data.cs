﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Solver2020_02
{
  public class Data
  {
    public string InputDataRaw { get; }
    public List<string> Lines { get; } = new List<string>();

    public Data(string inputData)
    {
      this.InputDataRaw = inputData;
      using(StringReader sr = new StringReader(inputData))
      {
        string line;
        while((line = sr.ReadLine()) != null)
        {
          Lines.Add(line);
        }
      }
    }

    internal int Solve1()
    {
      throw new NotImplementedException();
    }

    internal int Solve2()
    {
      throw new NotImplementedException();
    }
  }
}
