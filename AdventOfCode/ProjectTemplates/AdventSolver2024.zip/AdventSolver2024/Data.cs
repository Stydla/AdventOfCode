﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$
{
  internal class Data : DataBase
  {  
    public Data(string input) : base(input) 
    { 
      // optionaly parse data
    }

    public object Solve1()
    {
      throw new NotImplementedException();
    }

    public object Solve2()
    {
      throw new NotImplementedException();
    }


  }
}
